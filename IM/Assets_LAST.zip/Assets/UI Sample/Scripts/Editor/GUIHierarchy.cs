using UnityEditor;
using UnityEngine;
using System.Collections;

public class GUIHierarchy : BaseHierarchySort
{
	//public override bool ShouldDisplay(GameObject obj) { return obj.layer == LayerMask.NameToLayer("UI"); }
}
